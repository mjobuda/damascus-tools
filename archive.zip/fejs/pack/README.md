JavaScript bindings for the [Fe compiler](https://github.com/ethereum/fe)


![show](https://github.com/mjobuda/vscode-fe/blob/master/images/render1626136055486-min.gif)
