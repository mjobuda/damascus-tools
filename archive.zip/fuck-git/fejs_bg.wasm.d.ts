/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function compile_to_ast(a: number, b: number): number;
export function compile_to_lowered_ast(a: number, b: number): number;
export function get_token(a: number, b: number): number;
export function compile(a: number, b: number): number;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export function __wbindgen_exn_store(a: number): void;
